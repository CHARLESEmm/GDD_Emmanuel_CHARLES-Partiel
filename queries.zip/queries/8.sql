- Sélectionner les noms et prénoms de tous les employés:
			
		SELECT nom, prenom FROM employes;
