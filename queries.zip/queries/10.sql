-Sélectionner les employés triés par nom décroissant :

		SELECT * FROM employes ORDER BY nom DESC;