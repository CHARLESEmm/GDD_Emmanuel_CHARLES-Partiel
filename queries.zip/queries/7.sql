- Afficher le nom et le prénom des clients ayant effectué une réservation avec un total supérieur à 100:
    	      
            SELECT client.nom, client.prenom FROM client
		JOIN reservation ON client.id = reservation.client_id
		WHERE reservation.total > 100;
