/*-sélectionner les employés et les services qu'ils gèrent:*/

		SELECT employes.*, services.*
            FROM employes
            JOIN departement ON employes.departement_id = departement.department_id
            JOIN services ON departement.department_id = services.department_id;
