
/*creation de la base*/

CREATE DATABASE thehotel;


/*2 creation des tables*/
 use thehotel
 
CREATE TABLE employes (
    id INT PRIMARY KEY,
    nom VARCHAR(255) NOT NULL,
    prenom VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    numero_de_telephone VARCHAR(255) NOT NULL,
    Hire_date DATE NOT NULL,
    commission_pct INT NOT NULL,
    salaire DECIMAL(10,2) NOT NULL,
    departement_id INT,
    poste INT NOT null, 
    FOREIGN KEY (departement_id) REFERENCES thehotel.employes(id)
);

CREATE TABLE client (
    id INT PRIMARY KEY,
    nom VARCHAR(20) NOT NULL,
    prenom VARCHAR(20) NOT NULL,
    adresse VARCHAR(50),
    email VARCHAR(30) NOT NULL,
    numero_de_telephone VARCHAR(255) NOT NULL,
    paiement VARCHAR(50),
    historique_reservation VARCHAR(120)
);

CREATE TABLE chambre (
    id INT PRIMARY KEY,
    numero_chambre INT NOT NULL,
    id_hotel INT NOT NULL,
    id_reservation INT NOT NULL,
    etage INT NOT NULL,
    type VARCHAR(20),
    prix DECIMAL(10,2) NOT NULL,
    statut ENUM('Occupée','Libre','En attente') NOT NULL;
    FOREIGN KEY (ID_hotel) REFERENCES hotel(ID)
    
);

CREATE TABLE services (
    id INT PRIMARY KEY,
    nom VARCHAR(50),
    description TEXT NOT NULL,
    tarif DECIMAL (10,2) NOT NULL,
    id_reservation INT NOT NULL,
    department_id INT,
    FOREIGN KEY (department_id) REFERENCES departement(department_id)
    
);

CREATE TABLE departement (
    department_id INT PRIMARY KEY,
    nom VARCHAR(50) NOT NULL,
    id_hotel INT NOT NULL,
    manager_id INT NOT NULL,
    FOREIGN KEY (manager_id) REFERENCES employes(employes_id),
    FOREIGN KEY (id_hotel) REFERENCES hotel(id_hotel)
);


CREATE TABLE factures (
    facture_id INT PRIMARY KEY,
    date_facture DATE NOT NULL,
    montant DECIMAL(10,2) NOT NULL,
    client_id INT NOT NULL,
    employe_id INT NOT NULL,
    service_id INT NOT NULL,
    chambre_id INT NOT NULL,
    FOREIGN KEY (client_id) REFERENCES clients(client_id),
    FOREIGN KEY (employe_id) REFERENCES employes(employe_id),
    FOREIGN KEY (service_id) REFERENCES services(service_id),
    FOREIGN KEY (chambre_id) REFERENCES chambres(chambre_id)
);

CREATE TABLE reservation (
    reservation_id INT PRIMARY KEY,
    client_id INT NOT NULL,
    chambre_id INT NOT NULL,
    employe_id INT NOT NULL,
    date_debut DATE NOT NULL,
    date_fin DATE NOT NULL,
    nombre_personne INT NOT NULL,
    total FLOAT NOT NULL,
    commentaire VARCHAR(255),
    statut ENUM('Confirmée','Annulée','En attente') NOT NULL,
    FOREIGN KEY (client_id) REFERENCES client(client_id),
    FOREIGN KEY (chambre_id) REFERENCES chambre(chambre_id),
    FOREIGN KEY (employe_id) REFERENCES employes(employe_id)
);





