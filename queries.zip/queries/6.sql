-Afficher les chambres libres triées par numéro de chambre:

		SELECT * FROM chambre WHERE statut='Libre' ORDER BY numero_chambre;
