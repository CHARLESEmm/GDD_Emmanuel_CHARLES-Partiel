
/* exemple d'insertion de données dans les tables*/

use thehotel

INSERT INTO the_hotel (id, name, address,phone_number,email,capacity,chambre_dispo,reserved_rooms,number_of_employees)
VALUES (1, 'THEHOTEL', '7 rue de demange, 75002 Paris', '0123856759', 'thehotelsupport@gmail.com', '500', '250','250',105);

INSERT INTO chambre (id, numero_chambre, id_reservation, etage, type, prix, statut)
VALUES (9, 203, 9, 2, 'Double', 70, 'Libre');

INSERT INTO client (ID, nom, prenom, adresse, numero_de_telephone , email,paiement, historique_reservation) 
VALUES 
(1, 'Dupont', 'Jacques', '1 rue de la Paix', '0123456789', 'jacques.dupont@gmail.com', 'Carte de crédit', 'Réservation du 25/05/2022 au 27/05/2022'),

INSERT INTO reservation (reservation_id, client_id, chambre_id, employe_id, date_debut, date_fin, nombre_personne, total, commentaire) VALUES 
(11, 1, 203, 1, '2022-03-01', '2022-03-05', 2, 150, 'Première réservation,incroyable!!'),

INSERT INTO employes (id, nom, prenom, email, numero_de_telephone, hire_date, commission_pct, salaire, departement_id, poste) VALUES
(1, 'John', 'Smith', 'john.smith@example.com', '06-12-34-56-78', '2022-01-01', 0.1, 50000, 1, 'Manager'),

INSERT INTO factures (facture_id, date_facture, montant, client_id, employe_id, service_id, chambre_id, reservation_id)
VALUES(1, '2022-01-01', 100.50, 1, 1, 1, 1, 1), (2, '2022-01-02', 120.75, 2, 2, 2, 2, 2), (3, '2022-01-03', 150.25, 3, 3, 3, 3, 3),
(4, '2022-01-04', 75.50, 4, 4, 4, 4, 4),(5, '2022-01-05', 200.00, 5, 5, 5, 5, 5),(6, '2022-01-06', 250.00, 6, 6, 6, 6, 6),
(7, '2022-01-07', 300.00, 7, 7, 7, 7, 7),(8, '2022-01-08', 350.00, 8, 8, 8, 8, 8),(9, '2022-01-09', 400.00, 9, 9, 9, 9, 9);

INSERT INTO services (id, nom, description, tarif, reservation_id, department_id)
VALUES (1, 'Petit déjeuner buffet', 'Un petit déjeuner buffet complet comprenant des produits frais et locaux', 15.00, 1, 1),
(2, 'Service de chambre', 'Service de chambre disponible 24h/24 et 7j/7', 20.00, 2, 2),
(3, 'Piscine extérieure', 'Piscine extérieure ouverte en saison', 10.00, 3, 3),
(4, 'Salle de fitness', 'Salle de fitness équipée de machines de cardio et de musculation', 8.00, 4, 4),
(5, 'Service de blanchisserie', 'Service de blanchisserie professionnel disponible pour les clients', 5.00, 5, 5);


INSERT INTO departement (department_id, nom, id_hotel, manager_id) VALUES (1, 'Réception', 1, 1);
