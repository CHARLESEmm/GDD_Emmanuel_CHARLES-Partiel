/*- un client en particulier en utilisant son nom et prenom par exemple, je veux des informations sur le client "Petit Paul".*/

      		SELECT id, adresse, email, numero_de_telephone FROM client
				WHERE nom = 'Petit' AND prenom = 'Paul';

    /* En utilisant son ID exemple [5].*/
			
			SELECT * FROM client WHERE id ='5';