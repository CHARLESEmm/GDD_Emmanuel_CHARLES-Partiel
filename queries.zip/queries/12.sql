-Sélectionner les noms des services :

		SELECT nom FROM services;
