/*Afficher le nombre de réservations annulées:*/

		SELECT COUNT(*) FROM reservation WHERE statut='Annulée';