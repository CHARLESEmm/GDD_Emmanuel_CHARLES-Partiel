
SELECT id, adresse, email, numero_de_telephone FROM client
WHERE nom = 'Petit' AND prenom = 'Paul';