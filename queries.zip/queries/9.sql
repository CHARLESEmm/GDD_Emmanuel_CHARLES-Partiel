/*-Sélectionner le nombre total d'employés:*/

		SELECT COUNT(*) FROM employes;