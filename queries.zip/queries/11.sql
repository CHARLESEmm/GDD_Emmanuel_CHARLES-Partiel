-Sélectionner les employés qui ont une commission supérieure à 5%:

		SELECT * FROM employes WHERE commission_pct > '5';
