-Sélectionner le nombre total de services :

		SELECT COUNT(*) FROM services;